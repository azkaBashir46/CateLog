import 'package:catelog/pages/Model/item_product.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
class ResponseServices{
  Future<List<ItemModel>?> getProducts () async {
    var client=http.Client();
    var url=Uri.parse('https://jsonplaceholder.typicode.com/posts');
    var response=await client.get(url);
    if(response.statusCode==200){
     
      // var jsont=json.decode(response.body);
  //  Map<String, dynamic> map = jsonDecode(json);
      var jsont=response.body;
      
      return itemModelFromJson(jsont);
    
      
    }

  }
}

